<?php

return [
    'welcome' => 'مرحباً بك في OxygenFramework',
    'login' => 'تسجيل الدخول',
    'register' => 'التسجيل',
    'dashboard' => 'لوحة التحكم',
    'profile' => 'الملف الشخصي',
    'logout' => 'تسجيل الخروج',
    'greeting' => 'مرحباً، :name!',
    'description' => 'إطار عمل PHP مفتوح المصدر صُنع في الجزائر مع دعم مدمج لـ Python يجدد PHP.',
    'info' => 'بسيط، مضغوط، سهل التعلم!',
];
