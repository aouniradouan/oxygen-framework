<?php

return [
    'welcome' => 'Bienvenue sur OxygenFramework',
    'login' => 'Connexion',
    'register' => 'Inscription',
    'dashboard' => 'Tableau de bord',
    'profile' => 'Profil',
    'logout' => 'Déconnexion',
    'greeting' => 'Bonjour, :name!',
    'description' => 'Un framework PHP open source fait en Algérie avec un support intégré Python rajeunit PHP.',
    'info' => 'Simple, Compact, Facile d\'apprendre!',
];
