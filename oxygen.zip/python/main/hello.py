# Write hello World o display it in php file
print("Hello World")
